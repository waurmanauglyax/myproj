document.addEventListener('DOMContentLoaded', () => {
  loadEditedPassport();
});

const loadEditedPassport = () => {
  const editedPassport = JSON.parse(sessionStorage.getItem('editedPassport'));
  const editedOperations = JSON.parse(sessionStorage.getItem('editedOperations'));
  if (editedPassport) {
    renderEditedPassport(editedPassport);
    renderEditedOperations(editedOperations);
  }
};

const renderEditedPassport = passport => {
  const editedPassportTableBody = document.getElementById('editedPassportTableBody');
  editedPassportTableBody.innerHTML = `
    <tr>
      <td>${passport.div_no}</td>
      <td>${passport.pas_no}</td>
      <td>${passport.nom_code}</td>
      <td>${passport.nom_name}</td>
      <td>${passport.nom_size}</td>
      <td>${passport.order_no}</td>
      <td>${passport.pas_year}</td>
      <td>${passport.pas_date_add}</td>
      <td>${passport.pas_quantity}</td>
      <td>${passport.pas_date_edit}</td>
      <td>${passport.nom_designation}</td>
    </tr>
  `;
};

const renderEditedOperations = operations => {
  const editedOperationsTableBody = document.getElementById('editedOperationsTableBody');
  editedOperationsTableBody.innerHTML = '';
  operations.forEach(operation => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${operation.po_no}</td>
      <td>${operation.to_code}</td>
      <td>${operation.po_name_manual}</td>
      <td>${operation.po_tp_instruction}</td>
    `;
    editedOperationsTableBody.appendChild(row);
  });
};

const saveChanges = () => {
  
  alert('Изменения сохранены успешно!');
};
