let passportsData = [];
let operationsData = [];

document.addEventListener('DOMContentLoaded', async () => {
  await loadPassports();
  await loadOperations();
});

async function loadPassports() {
  const response = await fetch('passports.json');
  passportsData = await response.json();
  sessionStorage.setItem('passports', JSON.stringify(passportsData));
  renderTable(passportsData);
}

async function loadOperations() {
  const response = await fetch('operations.json');
  operationsData = await response.json();
  sessionStorage.setItem('operations', JSON.stringify(operationsData));
}

function renderTable(data) {
  const tableBody = document.getElementById('tableBody');
  tableBody.innerHTML = '';
  data.forEach(passport => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td><a href="passport.html?passportId=${passport.pas_id}">${formatPassportNumber(passport)}</a></td>
      <td>${formatNomCode(passport.nom_code)}</td>
      <td>${passport.nom_name}</td>
      <td>${formatDate(passport.pas_date_add)}</td>
    `;
    tableBody.appendChild(row);
  });
}

function formatDate(dateString) {
  const date = new Date(dateString);
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}.${month}.${year}`;
}

function formatNomCode(nomCode) {
  // Преобразование nomCode в строку
  nomCode = String(nomCode);
  
  // Форматирование nomCode с помощью padStart
  return nomCode.padStart(15, '0');
}

function formatOrderNo(orderNo) {
  orderNo = String(orderNo);
  return orderNo.padStart(6, '0');
}

function formatPassportNumber(passport) {
  return `${passport.pas_no}/${(passport.div_no)} ${passport.pas_year}`;
}

function applyPageSize() {
  const pageSizeInput = document.getElementById('pageSizeInput');
  const pageSize = parseInt(pageSizeInput.value);
  if (isNaN(pageSize) || pageSize <= 0) return;

  renderTable(passportsData.slice(0, pageSize));
}

function sortTable(field, order) {
  const sortedData = [...passportsData].sort((a, b) => {
    if (a[field] < b[field]) return order === 'asc' ? -1 : 1;
    if (a[field] > b[field]) return order === 'asc' ? 1 : -1;
    return 0;
  });
  renderTable(sortedData);
}

async function addPassport() {
  const form = document.getElementById('addPassportForm');
  const formData = new FormData(form);
  const newPassport = Object.fromEntries(formData.entries());

  passportsData.push(newPassport);
  sessionStorage.setItem('passports', JSON.stringify(passportsData));
  renderTable(passportsData);
  closeModal();
}

function openModal() {
  document.getElementById('myModal').style.display = 'block';
}

function closeModal() {
  document.getElementById('myModal').style.display = 'none';
}

function goBack() {
  window.history.back();
}

function redirectToEditedPassport() {
  const passportId = new URLSearchParams(window.location.search).get('passportId');
  const passport = passportsData.find(p => p.pas_id == passportId);
  if (passport) {
    sessionStorage.setItem('editedPassport', JSON.stringify(passport));
    const operations = operationsData.filter(op => op.pas_id == passportId);
    sessionStorage.setItem('editedOperations', JSON.stringify(operations));
  }
  window.location.href = `edited_passport.html?passportId=${passportId}`;
}

document.addEventListener('DOMContentLoaded', async () => {
  const passportId = new URLSearchParams(window.location.search).get('passportId');
  if (!passportId) return;

  const passport = passportsData.find(p => p.pas_id == passportId);
  if (!passport) return;

  document.getElementById('passportHeader').textContent = `Паспорт № ${formatPassportNumber(passport)}`;

  document.getElementById('divno').textContent = passport.div_no;
  document.getElementById('passportNumber').textContent = formatPassportNumber(passport);
  document.getElementById('code').textContent = formatNomCode(passport.nom_code);
  document.getElementById('detailName').textContent = passport.nom_name;
  document.getElementById('size').textContent = passport.nom_size;
  document.getElementById('orderNumber').textContent = formatOrderNo(passport.order_no);
  document.getElementById('year').textContent = passport.pas_year;
  document.getElementById('dateAdded').textContent = formatDate(passport.pas_date_add);
  document.getElementById('quantity').textContent = passport.pas_quantity;
  document.getElementById('dateEdited').textContent = formatDate(passport.pas_date_edit);
  document.getElementById('designation').textContent = passport.nom_designation;

  const operations = operationsData.filter(op => op.pas_id == passportId);
  const operationsTableBody = document.getElementById('operationsTableBody');
  operationsTableBody.innerHTML = '';
  operations.forEach(op => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${op.po_no}</td>
      <td>${op.to_code}</td>
      <td>${op.po_name_manual}</td>
      <td>${op.po_tp_instruction}</td>
      <td><button onclick="deleteOperation(${op.po_id})">Удалить</button></td>
    `;
    operationsTableBody.appendChild(row);
  });
});

async function addOperation() {
  openOperationModal();
}

async function saveOperation() {
  const form = document.getElementById('addOperationForm');
  const formData = new FormData(form);
  const newOperation = Object.fromEntries(formData.entries());

  operationsData.push(newOperation);
  sessionStorage.setItem('operations', JSON.stringify(operationsData));

  const operationsTableBody = document.getElementById('operationsTableBody');
  const row = document.createElement('tr');
  row.innerHTML = `
    <td>${newOperation.op_no}</td>
    <td>${newOperation.op_code}</td>
    <td>${newOperation.op_name}</td>
    <td>${newOperation.op_instr}</td>
    <td><button onclick="deleteOperation(${newOperation.op_id})">Удалить</button></td>
  `;
  operationsTableBody.appendChild(row);
  closeOperationModal();
}

function openOperationModal() {
  document.getElementById('operationModal').style.display = 'block';
}

function closeOperationModal() {
  document.getElementById('operationModal').style.display = 'none';
}

function deleteOperation(operationId) {
  operationsData = operationsData.filter(op => op.op_id !== operationId);
  sessionStorage.setItem('operations', JSON.stringify(operationsData));
  const rowToDelete = document.querySelector(`#operationsTableBody tr[data-id="${operationId}"]`);
  if (rowToDelete) rowToDelete.remove();
}

document.addEventListener('DOMContentLoaded', async () => {
  const passportId = new URLSearchParams(window.location.search).get('passportId');
  if (!passportId) return;

  const passportsData = JSON.parse(sessionStorage.getItem('passports')) || [];
  const operationsData = JSON.parse(sessionStorage.getItem('operations')) || [];

  const passport = passportsData.find(p => p.pas_id == passportId);
  if (!passport) return;

  document.getElementById('passportHeader').textContent = `Паспорт № ${formatPassportNumber(passport)}`;

  document.getElementById('divno').textContent = passport.div_no;
  document.getElementById('passportNumber').textContent = formatPassportNumber(passport);
  document.getElementById('code').textContent = formatNomCode(passport.nom_code);
  document.getElementById('detailName').textContent = passport.nom_name;
  document.getElementById('size').textContent = passport.nom_size;
  document.getElementById('orderNumber').textContent = passport.order_no;
  document.getElementById('year').textContent = passport.pas_year;
  document.getElementById('dateAdded').textContent = formatDate(passport.pas_date_add);
  document.getElementById('quantity').textContent = passport.pas_quantity;
  document.getElementById('dateEdited').textContent = passport.pas_date_edit;
  document.getElementById('designation').textContent = passport.nom_designation;

  const operations = operationsData.filter(op => op.pas_id == passportId);
  const operationsTableBody = document.getElementById('operationsTableBody');
  operationsTableBody.innerHTML = '';
  operations.forEach(op => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${op.po_no}</td>
      <td>${op.to_code}</td>
      <td>${op.po_name_manual}</td>
      <td>${op.po_tp_instruction}</td>
      <td><button onclick="deleteOperation(${op.po_id})" data-id="${op.po_id}">Удалить</button></td>
    `;
    operationsTableBody.appendChild(row);
  });
});

async function addOperation() {
  openOperationModal();
}

async function saveOperation() {
  const form = document.getElementById('addOperationForm');
  const formData = new FormData(form);
  const newOperation = Object.fromEntries(formData.entries());

  const operationsData = JSON.parse(sessionStorage.getItem('operations')) || [];
  
  newOperation.po_id = operationsData.length + 1; // пример для нового po_id, который вы можете настроить по своему усмотрению

  operationsData.push(newOperation);
  sessionStorage.setItem('operations', JSON.stringify(operationsData));

  const operationsTableBody = document.getElementById('operationsTableBody');
  const row = document.createElement('tr');
  row.innerHTML = `
    <td>${newOperation.po_no}</td>
    <td>${newOperation.to_code}</td>
    <td>${newOperation.po_name_manual}</td>
    <td>${newOperation.po_tp_instruction}</td>
    <td><button onclick="deleteOperation(${newOperation.po_id})" data-id="${newOperation.po_id}">Удалить</button></td>
  `;
  operationsTableBody.appendChild(row);
  closeOperationModal();
}

function openOperationModal() {
  document.getElementById('operationModal').style.display = 'block';
}

function closeOperationModal() {
  document.getElementById('operationModal').style.display = 'none';
}

async function deleteOperation(operationId) {
  let operationsData = JSON.parse(sessionStorage.getItem('operations')) || [];
  operationsData = operationsData.filter(op => op.po_id !== operationId);
  sessionStorage.setItem('operations', JSON.stringify(operationsData));

  const rowToDelete = document.querySelector(`#operationsTableBody button[data-id="${operationId}"]`).closest('tr');
  if (rowToDelete) rowToDelete.remove();
}